<footer class="text-center py-4" style="background-color: #22aac9;">
    <p class="text-white mb-0">Hak Cipta &copy; 2024 Muhammad Farras Thohari Ramadhan</p>
</footer>